export class Product {

    id: number;
    name: string;
    description: string;
    price: number;
    imageUrl: string;

    constructor(id ,name ,description='', price=0, imageUrl='https://cdn.shopify.com/s/files/1/1635/8053/files/christianlouboutin-sokate-3130694_R038_1_1200x1200.jpg?10440646187589873490')
    {
        this.id=id
        this.name=name
        this.description=description
        this.price=price
        this.imageUrl=imageUrl
    }

}
